/**
 * SEED CLEAN — Limpieza de pacientes de prueba persistentes
 *
 * Elimina todos los recursos etiquetados con el tag de seed:
 *   https://seguimiento.medplum.com.ar/tags|ckm-seed
 *
 * Borra en orden seguro: primero los recursos dependientes (Observations,
 * Conditions, RiskAssessments, Communications) y al final los Patients.
 *
 * Uso: npm run seed:clean
 */

import { MedplumClient } from '@medplum/core';
import { getAuthenticatedClient, logPhase } from '../config/medplum-client.js';

const SEED_TAG_TOKEN = 'https://seguimiento.medplum.com.ar/tags|ckm-seed';

async function deleteByTag(medplum: MedplumClient, resourceType: string): Promise<number> {
  let total = 0;
  // Paginar de a 100 hasta vaciar
  let resources = await medplum.searchResources(resourceType as any, {
    _tag: SEED_TAG_TOKEN,
    _count: 100
  });

  while (resources.length > 0) {
    for (const r of resources) {
      await medplum.deleteResource(resourceType as any, (r as any).id);
      total++;
    }
    resources = await medplum.searchResources(resourceType as any, {
      _tag: SEED_TAG_TOKEN,
      _count: 100
    });
  }
  return total;
}

async function deleteClinicalDataOfSeedPatients(medplum: MedplumClient): Promise<void> {
  // RiskAssessments y Communications generados por los Bots NO llevan el tag seed,
  // así que los borramos buscando por los pacientes seed antes de eliminar a estos.
  const patients = await medplum.searchResources('Patient', {
    _tag: SEED_TAG_TOKEN,
    _count: 100
  });

  for (const p of patients) {
    for (const type of ['RiskAssessment', 'Communication'] as const) {
      const linked = await medplum.searchResources(type, {
        subject: `Patient/${p.id}`,
        _count: 200
      });
      for (const r of linked) {
        await medplum.deleteResource(type, r.id!);
      }
    }
  }
}

async function main(): Promise<void> {
  logPhase('SEED CLEAN — Limpieza de pacientes de prueba');

  const medplum = await getAuthenticatedClient();

  console.log('\n→ Eliminando datos clínicos generados por los Bots (RiskAssessment, Communication)...');
  await deleteClinicalDataOfSeedPatients(medplum);

  console.log('→ Eliminando recursos etiquetados con el tag seed...\n');

  // Orden: dependientes primero, Patient al final
  const order = ['Observation', 'Condition', 'RiskAssessment', 'Communication', 'QuestionnaireResponse', 'Patient'];
  let grandTotal = 0;

  for (const type of order) {
    const count = await deleteByTag(medplum, type);
    if (count > 0) {
      console.log(`  ✓ ${type}: ${count} eliminados`);
      grandTotal += count;
    }
  }

  console.log('\n' + '─'.repeat(60));
  console.log(`✓ Limpieza completa: ${grandTotal} recursos eliminados`);
  console.log('─'.repeat(60) + '\n');
}

main().catch((err) => {
  console.error('\n✗ Error en limpieza:', err.message);
  process.exit(1);
});
