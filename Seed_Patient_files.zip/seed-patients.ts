/**
 * SEED — Pacientes de prueba persistentes para desarrollo del FrontEnd
 *
 * Crea un conjunto de pacientes representativos de cada estadío CKM, con las
 * Observations que disparan los Bots (CKMStager → PREVENTCalculator), de modo que
 * el FrontEnd de seguimiento.medplum.com.ar tenga datos reales para mostrar:
 * estadío, Score PREVENT, hGraph, alertas.
 *
 * A DIFERENCIA de test:e2e, estos pacientes NO se borran. Quedan persistentes.
 * Todos llevan el tag https://seguimiento.medplum.com.ar/tags|ckm-seed para poder
 * identificarlos y limpiarlos después con: npm run seed:clean
 *
 * Uso: npm run seed:patients
 *
 * Idempotente: si un paciente seed ya existe (mismo identifier), lo reutiliza y
 * actualiza sus Observations en vez de duplicarlo. Seguro re-ejecutar.
 */

import { MedplumClient, createReference } from '@medplum/core';
import type { Patient, Observation, Condition } from '@medplum/fhirtypes';
import { getAuthenticatedClient, logPhase } from '../config/medplum-client.js';

const SEED_TAG = { system: 'https://seguimiento.medplum.com.ar/tags', code: 'ckm-seed' };
const SEED_ID_SYSTEM = 'https://seguimiento.medplum.com.ar/seed-patient';

const LOINC = {
  sbp: '8480-6', dbp: '8462-4',
  bmi: '39156-5', waist: '56086-2',
  glucoseFasting: '1558-6', hba1c: '4548-4',
  cholesterolTotal: '2093-3', ldlc: '13457-7', hdlc: '2085-9', triglycerides: '2571-8',
  creatinine: '38483-4', egfr: '62238-1', uacr: '9318-7', potassium: '6298-4',
  ntProBNP: '33762-6', cac: '41970-0'
} as const;

interface LabValue { code: keyof typeof LOINC; display: string; value: number; unit: string; }

interface SeedPatient {
  seedId: string;
  family: string;
  given: string;
  gender: 'male' | 'female';
  birthDate: string;
  expectedStage: string;     // documentación: estadío esperado tras los Bots
  profile: string;           // descripción clínica
  labs: LabValue[];
  conditions?: { code: string; display: string }[];  // ICD-10 para Estadío 4
}

// ─────────────────────────────────────────────────────────────────────────────
// PERFILES DE PACIENTES — uno por estadío, cubriendo subespecialidades clave
// ─────────────────────────────────────────────────────────────────────────────

const SEED_PATIENTS: SeedPatient[] = [

  // ── Estadío 0 — Sin factores de riesgo (Atención Primaria) ──────────────
  {
    seedId: 'ckm-seed-stage0',
    family: 'Demo Estadío 0',
    given: 'Ana',
    gender: 'female',
    birthDate: '1986-04-12',  // ~40 años
    expectedStage: '0',
    profile: 'Mujer sana de 40 años, sin factores de riesgo. Prevención primordial.',
    labs: [
      { code: 'sbp', display: 'PA sistólica', value: 112, unit: 'mm[Hg]' },
      { code: 'dbp', display: 'PA diastólica', value: 72, unit: 'mm[Hg]' },
      { code: 'bmi', display: 'IMC', value: 22.5, unit: 'kg/m2' },
      { code: 'waist', display: 'Circunferencia de cintura', value: 78, unit: 'cm' },
      { code: 'glucoseFasting', display: 'Glucemia en ayunas', value: 88, unit: 'mg/dL' },
      { code: 'hba1c', display: 'HbA1c', value: 5.2, unit: '%' },
      { code: 'cholesterolTotal', display: 'Colesterol total', value: 175, unit: 'mg/dL' },
      { code: 'ldlc', display: 'LDL-C', value: 95, unit: 'mg/dL' },
      { code: 'hdlc', display: 'HDL-C', value: 62, unit: 'mg/dL' },
      { code: 'triglycerides', display: 'Triglicéridos', value: 90, unit: 'mg/dL' },
      { code: 'egfr', display: 'eGFR', value: 98, unit: 'mL/min/{1.73_m2}' },
      { code: 'uacr', display: 'UACR', value: 8, unit: 'mg/g' }
    ]
  },

  // ── Estadío 1 — Exceso de grasa corporal + prediabetes (Endocrinología) ─
  {
    seedId: 'ckm-seed-stage1',
    family: 'Demo Estadío 1',
    given: 'Carlos',
    gender: 'male',
    birthDate: '1979-09-23',  // ~46 años
    expectedStage: '1',
    profile: 'Varón de 46 años con sobrepeso, obesidad abdominal y prediabetes. Endocrinología.',
    labs: [
      { code: 'sbp', display: 'PA sistólica', value: 122, unit: 'mm[Hg]' },
      { code: 'dbp', display: 'PA diastólica', value: 78, unit: 'mm[Hg]' },
      { code: 'bmi', display: 'IMC', value: 28.4, unit: 'kg/m2' },
      { code: 'waist', display: 'Circunferencia de cintura', value: 106, unit: 'cm' },
      { code: 'glucoseFasting', display: 'Glucemia en ayunas', value: 112, unit: 'mg/dL' },
      { code: 'hba1c', display: 'HbA1c', value: 6.0, unit: '%' },
      { code: 'cholesterolTotal', display: 'Colesterol total', value: 198, unit: 'mg/dL' },
      { code: 'ldlc', display: 'LDL-C', value: 118, unit: 'mg/dL' },
      { code: 'hdlc', display: 'HDL-C', value: 44, unit: 'mg/dL' },
      { code: 'triglycerides', display: 'Triglicéridos', value: 142, unit: 'mg/dL' },
      { code: 'egfr', display: 'eGFR', value: 88, unit: 'mL/min/{1.73_m2}' },
      { code: 'uacr', display: 'UACR', value: 18, unit: 'mg/g' }
    ]
  },

  // ── Estadío 2 — DM2 + HTA + ERC moderada (Diabetología / Nefrología) ────
  {
    seedId: 'ckm-seed-stage2',
    family: 'Demo Estadío 2',
    given: 'Roberto',
    gender: 'male',
    birthDate: '1964-06-10',  // ~61 años
    expectedStage: '2',
    profile: 'Varón de 61 años con DM2, HTA y ERC moderada con albuminuria. Diabetología + Nefrología.',
    labs: [
      { code: 'sbp', display: 'PA sistólica', value: 138, unit: 'mm[Hg]' },
      { code: 'dbp', display: 'PA diastólica', value: 86, unit: 'mm[Hg]' },
      { code: 'bmi', display: 'IMC', value: 31.2, unit: 'kg/m2' },
      { code: 'waist', display: 'Circunferencia de cintura', value: 110, unit: 'cm' },
      { code: 'glucoseFasting', display: 'Glucemia en ayunas', value: 152, unit: 'mg/dL' },
      { code: 'hba1c', display: 'HbA1c', value: 7.2, unit: '%' },
      { code: 'cholesterolTotal', display: 'Colesterol total', value: 210, unit: 'mg/dL' },
      { code: 'ldlc', display: 'LDL-C', value: 128, unit: 'mg/dL' },
      { code: 'hdlc', display: 'HDL-C', value: 42, unit: 'mg/dL' },
      { code: 'triglycerides', display: 'Triglicéridos', value: 188, unit: 'mg/dL' },
      { code: 'creatinine', display: 'Creatinina sérica', value: 1.42, unit: 'mg/dL' },
      { code: 'egfr', display: 'eGFR', value: 58, unit: 'mL/min/{1.73_m2}' },
      { code: 'uacr', display: 'UACR', value: 145, unit: 'mg/g' },
      { code: 'potassium', display: 'Potasio sérico', value: 4.6, unit: 'mEq/L' }
    ]
  },

  // ── Estadío 2 — Mujer post-diabetes gestacional (Corazón y Mujer) ───────
  {
    seedId: 'ckm-seed-stage2-women',
    family: 'Demo Corazón y Mujer',
    given: 'Lucía',
    gender: 'female',
    birthDate: '1990-11-05',  // ~35 años
    expectedStage: '2',
    profile: 'Mujer de 35 años post-diabetes gestacional, con HTA y prediabetes persistente. Corazón y Mujer.',
    labs: [
      { code: 'sbp', display: 'PA sistólica', value: 134, unit: 'mm[Hg]' },
      { code: 'dbp', display: 'PA diastólica', value: 84, unit: 'mm[Hg]' },
      { code: 'bmi', display: 'IMC', value: 29.8, unit: 'kg/m2' },
      { code: 'waist', display: 'Circunferencia de cintura', value: 92, unit: 'cm' },
      { code: 'glucoseFasting', display: 'Glucemia en ayunas', value: 118, unit: 'mg/dL' },
      { code: 'hba1c', display: 'HbA1c', value: 6.2, unit: '%' },
      { code: 'cholesterolTotal', display: 'Colesterol total', value: 192, unit: 'mg/dL' },
      { code: 'ldlc', display: 'LDL-C', value: 112, unit: 'mg/dL' },
      { code: 'hdlc', display: 'HDL-C', value: 52, unit: 'mg/dL' },
      { code: 'triglycerides', display: 'Triglicéridos', value: 156, unit: 'mg/dL' },
      { code: 'egfr', display: 'eGFR', value: 95, unit: 'mL/min/{1.73_m2}' },
      { code: 'uacr', display: 'UACR', value: 22, unit: 'mg/g' }
    ]
  },

  // ── Estadío 3 — ECV subclínica + pre-IC (Cardiología / Lipidología) ─────
  {
    seedId: 'ckm-seed-stage3',
    family: 'Demo Estadío 3',
    given: 'Jorge',
    gender: 'male',
    birthDate: '1958-02-18',  // ~68 años
    expectedStage: '3',
    profile: 'Varón de 68 años con aterosclerosis subclínica (CAC alto) y pre-IC (NT-proBNP elevado). Cardiología.',
    labs: [
      { code: 'sbp', display: 'PA sistólica', value: 142, unit: 'mm[Hg]' },
      { code: 'dbp', display: 'PA diastólica', value: 88, unit: 'mm[Hg]' },
      { code: 'bmi', display: 'IMC', value: 30.5, unit: 'kg/m2' },
      { code: 'waist', display: 'Circunferencia de cintura', value: 108, unit: 'cm' },
      { code: 'glucoseFasting', display: 'Glucemia en ayunas', value: 134, unit: 'mg/dL' },
      { code: 'hba1c', display: 'HbA1c', value: 6.8, unit: '%' },
      { code: 'cholesterolTotal', display: 'Colesterol total', value: 224, unit: 'mg/dL' },
      { code: 'ldlc', display: 'LDL-C', value: 148, unit: 'mg/dL' },
      { code: 'hdlc', display: 'HDL-C', value: 38, unit: 'mg/dL' },
      { code: 'triglycerides', display: 'Triglicéridos', value: 210, unit: 'mg/dL' },
      { code: 'creatinine', display: 'Creatinina sérica', value: 1.18, unit: 'mg/dL' },
      { code: 'egfr', display: 'eGFR', value: 64, unit: 'mL/min/{1.73_m2}' },
      { code: 'uacr', display: 'UACR', value: 95, unit: 'mg/g' },
      { code: 'ntProBNP', display: 'NT-proBNP', value: 220, unit: 'pg/mL' },
      { code: 'cac', display: 'CAC score', value: 185, unit: '{Agatston}' }
    ]
  },

  // ── Estadío 4a — ECV clínica sin falla renal (Cardiología) ──────────────
  {
    seedId: 'ckm-seed-stage4a',
    family: 'Demo Estadío 4a',
    given: 'Héctor',
    gender: 'male',
    birthDate: '1954-07-30',  // ~71 años
    expectedStage: '4',
    profile: 'Varón de 71 años con cardiopatía isquémica e insuficiencia cardíaca, sin falla renal. Cardiología.',
    labs: [
      { code: 'sbp', display: 'PA sistólica', value: 128, unit: 'mm[Hg]' },
      { code: 'dbp', display: 'PA diastólica', value: 78, unit: 'mm[Hg]' },
      { code: 'bmi', display: 'IMC', value: 29.0, unit: 'kg/m2' },
      { code: 'glucoseFasting', display: 'Glucemia en ayunas', value: 145, unit: 'mg/dL' },
      { code: 'hba1c', display: 'HbA1c', value: 7.5, unit: '%' },
      { code: 'ldlc', display: 'LDL-C', value: 88, unit: 'mg/dL' },
      { code: 'hdlc', display: 'HDL-C', value: 36, unit: 'mg/dL' },
      { code: 'triglycerides', display: 'Triglicéridos', value: 175, unit: 'mg/dL' },
      { code: 'egfr', display: 'eGFR', value: 52, unit: 'mL/min/{1.73_m2}' },
      { code: 'uacr', display: 'UACR', value: 160, unit: 'mg/g' },
      { code: 'ntProBNP', display: 'NT-proBNP', value: 1250, unit: 'pg/mL' }
    ],
    conditions: [
      { code: 'I25.1', display: 'Cardiopatía isquémica aterosclerótica' },
      { code: 'I50.9', display: 'Insuficiencia cardíaca' }
    ]
  },

  // ── Estadío 4b — ECV clínica + falla renal (Nefrología / Cardiología) ───
  {
    seedId: 'ckm-seed-stage4b',
    family: 'Demo Estadío 4b',
    given: 'Marta',
    gender: 'female',
    birthDate: '1951-12-03',  // ~74 años
    expectedStage: '4',
    profile: 'Mujer de 74 años con fibrilación auricular y enfermedad renal avanzada (G5). Nefrología + Cardiología.',
    labs: [
      { code: 'sbp', display: 'PA sistólica', value: 145, unit: 'mm[Hg]' },
      { code: 'dbp', display: 'PA diastólica', value: 82, unit: 'mm[Hg]' },
      { code: 'bmi', display: 'IMC', value: 27.5, unit: 'kg/m2' },
      { code: 'glucoseFasting', display: 'Glucemia en ayunas', value: 138, unit: 'mg/dL' },
      { code: 'hba1c', display: 'HbA1c', value: 7.0, unit: '%' },
      { code: 'ldlc', display: 'LDL-C', value: 72, unit: 'mg/dL' },
      { code: 'hdlc', display: 'HDL-C', value: 44, unit: 'mg/dL' },
      { code: 'triglycerides', display: 'Triglicéridos', value: 165, unit: 'mg/dL' },
      { code: 'creatinine', display: 'Creatinina sérica', value: 4.8, unit: 'mg/dL' },
      { code: 'egfr', display: 'eGFR', value: 12, unit: 'mL/min/{1.73_m2}' },
      { code: 'uacr', display: 'UACR', value: 480, unit: 'mg/g' },
      { code: 'potassium', display: 'Potasio sérico', value: 5.2, unit: 'mEq/L' },
      { code: 'ntProBNP', display: 'NT-proBNP', value: 2100, unit: 'pg/mL' }
    ],
    conditions: [
      { code: 'I48.0', display: 'Fibrilación auricular' },
      { code: 'N18.5', display: 'Enfermedad renal crónica estadío 5' }
    ]
  }
];

// ─────────────────────────────────────────────────────────────────────────────
// CREACIÓN / ACTUALIZACIÓN DE UN PACIENTE SEED
// ─────────────────────────────────────────────────────────────────────────────

async function upsertSeedPatient(medplum: MedplumClient, seed: SeedPatient): Promise<Patient> {
  // Buscar paciente existente por identifier de seed
  const existing = await medplum.searchResources('Patient', {
    identifier: `${SEED_ID_SYSTEM}|${seed.seedId}`,
    _count: 1
  });

  const patientData: Patient = {
    resourceType: 'Patient',
    identifier: [{ system: SEED_ID_SYSTEM, value: seed.seedId }],
    meta: { tag: [SEED_TAG] },
    name: [{ family: seed.family, given: [seed.given] }],
    gender: seed.gender,
    birthDate: seed.birthDate
  };

  let patient: Patient;
  if (existing.length > 0) {
    patient = await medplum.updateResource({ ...patientData, id: existing[0].id });
    // Limpiar Observations y Conditions previas de este paciente seed para evitar acumulación
    await deletePatientClinicalData(medplum, patient.id!);
  } else {
    patient = await medplum.createResource(patientData);
  }

  return patient;
}

async function deletePatientClinicalData(medplum: MedplumClient, patientId: string): Promise<void> {
  for (const type of ['Observation', 'Condition'] as const) {
    const resources = await medplum.searchResources(type, {
      subject: `Patient/${patientId}`,
      _count: 200
    });
    for (const r of resources) {
      await medplum.deleteResource(type, r.id!);
    }
  }
}

async function createLab(
  medplum: MedplumClient,
  patient: Patient,
  lab: LabValue
): Promise<void> {
  const obs: Observation = {
    resourceType: 'Observation',
    status: 'final',
    meta: { tag: [SEED_TAG] },
    category: [{ coding: [{ system: 'http://terminology.hl7.org/CodeSystem/observation-category', code: 'laboratory' }] }],
    code: { coding: [{ system: 'http://loinc.org', code: LOINC[lab.code], display: lab.display }] },
    subject: createReference(patient),
    effectiveDateTime: new Date().toISOString(),
    valueQuantity: { value: lab.value, unit: lab.unit, system: 'http://unitsofmeasure.org' }
  };
  await medplum.createResource(obs);
}

async function createCondition(
  medplum: MedplumClient,
  patient: Patient,
  cond: { code: string; display: string }
): Promise<void> {
  const condition: Condition = {
    resourceType: 'Condition',
    meta: { tag: [SEED_TAG] },
    clinicalStatus: { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/condition-clinical', code: 'active' }] },
    verificationStatus: { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/condition-ver-status', code: 'confirmed' }] },
    code: { coding: [{ system: 'http://hl7.org/fhir/sid/icd-10', code: cond.code, display: cond.display }] },
    subject: createReference(patient)
  };
  await medplum.createResource(condition);
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN
// ─────────────────────────────────────────────────────────────────────────────

async function main(): Promise<void> {
  logPhase('SEED — Pacientes de prueba persistentes CKM');

  const medplum = await getAuthenticatedClient();

  console.log(`\n→ Creando ${SEED_PATIENTS.length} pacientes seed...\n`);

  for (const seed of SEED_PATIENTS) {
    console.log(`  ${seed.given} ${seed.family} (esperado: Estadío ${seed.expectedStage})`);
    console.log(`    ${seed.profile}`);

    const patient = await upsertSeedPatient(medplum, seed);

    // Crear Conditions primero (algunas disparan CKMStager hacia Estadío 4)
    if (seed.conditions) {
      for (const cond of seed.conditions) {
        await createCondition(medplum, patient, cond);
      }
    }

    // Crear las Observations (cada una puede disparar los Bots)
    for (const lab of seed.labs) {
      await createLab(medplum, patient, lab);
    }

    console.log(`    ✓ Patient/${patient.id} — ${seed.labs.length} labs${seed.conditions ? `, ${seed.conditions.length} condiciones` : ''}\n`);
  }

  // Dar tiempo a que los Bots procesen el último lote
  console.log('→ Esperando 10s a que los Bots terminen de procesar...');
  await new Promise(r => setTimeout(r, 10000));

  // Reporte final: verificar estadíos asignados
  console.log('\n→ Verificando estadíos asignados por los Bots...\n');
  for (const seed of SEED_PATIENTS) {
    const found = await medplum.searchResources('Patient', {
      identifier: `${SEED_ID_SYSTEM}|${seed.seedId}`,
      _count: 1
    });
    if (found.length > 0) {
      const stageExt = found[0].extension?.find(e =>
        e.url === 'https://seguimiento.medplum.com.ar/fhir/StructureDefinition/CKMStage');
      const actualStage = stageExt?.valueInteger;
      const match = String(actualStage) === seed.expectedStage ? '✓' : '⚠';
      console.log(`  ${match} ${seed.given} ${seed.family}: esperado ${seed.expectedStage}, asignado ${actualStage ?? 'sin clasificar'}`);
    }
  }

  console.log('\n' + '─'.repeat(60));
  console.log(`✓ Seed completo: ${SEED_PATIENTS.length} pacientes persistentes creados`);
  console.log(`  Tag de identificación: ${SEED_TAG.system}|${SEED_TAG.code}`);
  console.log(`  Para limpiarlos: npm run seed:clean`);
  console.log('─'.repeat(60) + '\n');
  console.log('Nota: si algún estadío no coincide con lo esperado, revisar que los');
  console.log('Bots estén desplegados y las Subscriptions activas (Fases 2 y 3).\n');
}

main().catch((err) => {
  console.error('\n✗ Error en seed:', err.message);
  process.exit(1);
});
