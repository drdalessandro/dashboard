/**
 * PREVENT → FHIR R4 RiskAssessment builder
 *
 * Convierte el resultado del motor PREVENT en un recurso FHIR R4
 * RiskAssessment que puede guardarse directamente en Medplum.
 *
 * Referencia: HL7 FHIR R4 RiskAssessment
 * https://www.hl7.org/fhir/riskassessment.html
 */

import type { PreventResult } from './prevent-engine';

// LOINC codes para los predictores PREVENT
const LOINC = {
  CVD_10Y:   '79423-0',  // Cardiovascular disease 10Y risk
  CVD_30Y:   '96021-0',  // Placeholder para 30y (extensión)
  HF_10Y:    '79424-8',  // Heart failure 10Y risk
  ASCVD_10Y: '79423-0',  // ASCVD risk (mismo base, diferenciado por outcome)
  PREVENT:   'PREVENT-AHA-2024', // Código local hasta LOINC oficial
};

// Sistema de codificación local UCA
const UCA_SYSTEM = 'https://api.medplum.com.ar/fhir/CodeSystem/prevent-model';

// Categorías de riesgo → ClinicalStatus SNOMED
const RISK_SNOMED: Record<string, { code: string; display: string }> = {
  low:          { code: '723505004', display: 'Low cardiovascular risk' },
  borderline:   { code: '723506003', display: 'Borderline cardiovascular risk' },
  intermediate: { code: '723507007', display: 'Intermediate cardiovascular risk' },
  high:         { code: '723508002', display: 'High cardiovascular risk' },
};

// Recomendaciones clínicas por categoría (AHA/ACC 2019 Primary Prevention)
const RECOMMENDATIONS: Record<string, string> = {
  low: 'Mantener estilos de vida saludables. Control periódico de factores de riesgo. No se indica tratamiento farmacológico preventivo de rutina.',
  borderline: 'Discutir inicio de estatina con el paciente. Evaluar factores de riesgo potenciadores (eGFR, UACR, PCR, CAC). Considerar aspirina solo si riesgo > beneficio.',
  intermediate: 'Iniciar tratamiento con estatina de alta o moderada intensidad. Control estricto de TA y glucemia. En diabetes: considerar SGLT2i preventivo. Reevaluar en 6 meses.',
  high: 'Tratamiento farmacológico intensivo. Si IC establecida: iniciar 4 pilares GDMT (ARNi/ACEi + beta-bloqueante + ARM + SGLT2i). Derivar a especialista en IC avanzada si corresponde.',
};

export function buildRiskAssessmentFHIR(
  result: PreventResult,
  patientRef: string,   // ej: "Patient/abc123"
  performerRef: string, // ej: "Practitioner/xyz789" (el Bot)
  encounterId?: string,
): object {
  const snomed = RISK_SNOMED[result.riskCategory];
  const recommendation = RECOMMENDATIONS[result.riskCategory];

  const pct = (v: number) => Math.round(v * 1000) / 10; // → 1 decimal %

  return {
    resourceType: 'RiskAssessment',
    meta: {
      profile: ['https://api.medplum.com.ar/fhir/StructureDefinition/prevent-risk-assessment'],
    },
    status: 'final',
    method: {
      coding: [{
        system: UCA_SYSTEM,
        code: 'PREVENT-2024-base',
        display: 'AHA PREVENT Equations 2024 — Base model (Khan et al., Circulation 2024)',
      }],
    },
    subject: { reference: patientRef },
    performer: { reference: performerRef },
    ...(encounterId ? { encounter: { reference: `Encounter/${encounterId}` } } : {}),
    occurrenceDateTime: result.calculatedAt,
    basis: buildBasisExtensions(result.input),
    prediction: [
      // CVD total — 10 años
      {
        outcome: {
          coding: [{
            system: 'http://snomed.info/sct',
            code: '49601007',
            display: 'Cardiovascular disease',
          }],
        },
        probabilityDecimal: parseFloat(pct(result.cvd10y).toFixed(1)) / 100,
        whenPeriod: { end: addYears(result.calculatedAt, 10) },
        rationale: `Riesgo de CVD total (ASCVD + IC) a 10 años: ${pct(result.cvd10y).toFixed(1)}%`,
        extension: [{
          url: `${UCA_SYSTEM}/outcome-type`,
          valueCode: 'total-cvd-10y',
        }],
      },
      // ASCVD — 10 años
      {
        outcome: {
          coding: [{
            system: 'http://snomed.info/sct',
            code: '155682002',
            display: 'Atherosclerotic cardiovascular disease',
          }],
        },
        probabilityDecimal: parseFloat(pct(result.ascvd10y).toFixed(1)) / 100,
        whenPeriod: { end: addYears(result.calculatedAt, 10) },
        rationale: `Riesgo de ASCVD (IAM + ACV) a 10 años: ${pct(result.ascvd10y).toFixed(1)}%`,
        extension: [{
          url: `${UCA_SYSTEM}/outcome-type`,
          valueCode: 'ascvd-10y',
        }],
      },
      // IC incidente — 10 años
      {
        outcome: {
          coding: [{
            system: 'http://snomed.info/sct',
            code: '84114007',
            display: 'Heart failure',
          }],
        },
        probabilityDecimal: parseFloat(pct(result.hf10y).toFixed(1)) / 100,
        whenPeriod: { end: addYears(result.calculatedAt, 10) },
        rationale: `Riesgo de insuficiencia cardíaca incidente a 10 años: ${pct(result.hf10y).toFixed(1)}%`,
        extension: [{
          url: `${UCA_SYSTEM}/outcome-type`,
          valueCode: 'hf-10y',
        }],
      },
      // CVD total — 30 años
      {
        outcome: {
          coding: [{
            system: 'http://snomed.info/sct',
            code: '49601007',
            display: 'Cardiovascular disease',
          }],
        },
        probabilityDecimal: parseFloat(pct(result.cvd30y).toFixed(1)) / 100,
        whenPeriod: { end: addYears(result.calculatedAt, 30) },
        rationale: `Riesgo de CVD total a 30 años: ${pct(result.cvd30y).toFixed(1)}%`,
        extension: [{
          url: `${UCA_SYSTEM}/outcome-type`,
          valueCode: 'total-cvd-30y',
        }],
      },
      // IC — 30 años
      {
        outcome: {
          coding: [{
            system: 'http://snomed.info/sct',
            code: '84114007',
            display: 'Heart failure',
          }],
        },
        probabilityDecimal: parseFloat(pct(result.hf30y).toFixed(1)) / 100,
        whenPeriod: { end: addYears(result.calculatedAt, 30) },
        rationale: `Riesgo de insuficiencia cardíaca a 30 años: ${pct(result.hf30y).toFixed(1)}%`,
        extension: [{
          url: `${UCA_SYSTEM}/outcome-type`,
          valueCode: 'hf-30y',
        }],
      },
    ],
    mitigation: recommendation,
    note: [{
      text: `Categoría de riesgo AHA/ACC 2019: ${result.riskCategory.toUpperCase()}. ` +
            `Modelo: AHA PREVENT 2024 (Khan et al., Circulation 2024). ` +
            `Predictor lineal CVD: ${result.lp.cvd.toFixed(4)}, ASCVD: ${result.lp.ascvd.toFixed(4)}, HF: ${result.lp.hf.toFixed(4)}. ` +
            `Solo prevención primaria. No reemplaza evaluación clínica.`,
    }],
    // Clasificación de riesgo como CodeableConcept
    extension: [{
      url: `${UCA_SYSTEM}/risk-category`,
      valueCodeableConcept: {
        coding: [snomed],
        text: `Riesgo ${result.riskCategory} — AHA/ACC Primary Prevention 2019`,
      },
    }, {
      url: `${UCA_SYSTEM}/model-version`,
      valueString: result.modelVersion,
    }],
  };
}

function addYears(isoDate: string, years: number): string {
  const d = new Date(isoDate);
  d.setFullYear(d.getFullYear() + years);
  return d.toISOString().split('T')[0];
}

// Construye las referencias a los Observations usados como base del cálculo
function buildBasisExtensions(input: import('./prevent-engine').PreventInput): Array<{ reference: string }> {
  // En producción, estos serían referencias a los Observation FHIR reales del paciente.
  // El Bot recibirá estas referencias como parte del Bundle de entrada.
  // Aquí devolvemos un placeholder para la estructura.
  return [
    { reference: '#obs-sbp' },
    { reference: '#obs-cholesterol' },
    { reference: '#obs-hdl' },
    { reference: '#obs-egfr' },
    { reference: '#obs-bmi' },
  ];
}
