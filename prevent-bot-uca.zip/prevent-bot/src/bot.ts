/**
 * PREVENT Bot — Medplum Subscription Bot
 * =========================================
 * Desplegado en: app.medplum.com.ar → proyecto IC UCA → Bots
 *
 * TRIGGER: Subscription en Observation con categoría "vital-signs" o
 *   "laboratory" para los LOINC relevantes (peso, TA, colesterol, eGFR).
 *   También puede invocarse manualmente pasando un Patient resource.
 *
 * FLUJO:
 *   1. Recibe el evento del trigger (Observation o Patient)
 *   2. Busca todas las Observations recientes del paciente
 *   3. Extrae los últimos valores de cada predictor PREVENT
 *   4. Corre el motor PREVENT
 *   5. Persiste el resultado como RiskAssessment FHIR R4
 *   6. Si el riesgo es alto → dispara alerta (Communication FHIR)
 *
 * Referencia Medplum Bots:
 *   https://www.medplum.com/docs/bots/bot-basics
 *
 * Khan et al., Circulation 2024;149:430–449
 */

import type { BotEvent, MedplumClient } from '@medplum/core';
import type { Observation, Patient, RiskAssessment, Bundle, Communication } from '@medplum/fhirtypes';
import { calculatePREVENT, PreventValidationError } from './prevent-engine';
import type { PreventInput, BiologicalSex } from './prevent-engine';
import { buildRiskAssessmentFHIR } from './fhir-builder';

// ─────────────────────────────────────────────────────────────
// CÓDIGOS LOINC DE LOS PREDICTORES PREVENT
// ─────────────────────────────────────────────────────────────

const LOINC_CODES = {
  SBP:               '8480-6',   // Systolic blood pressure
  TOTAL_CHOLESTEROL: '2093-3',   // Cholesterol [Mass/volume] in Serum
  HDL_C:             '2085-9',   // HDL Cholesterol
  EGFR:              '98979-8',  // eGFR CKD-EPI 2021 (creatinina)
  BMI:               '39156-5',  // Body mass index
  // Condiciones como Condition resource:
  // Diabetes: SNOMED 73211009 / ICD-10 E11
  // Tabaquismo: SNOMED 77176002
};

// Ventana de tiempo para buscar Observations recientes (días)
const LOOKBACK_DAYS = 180;

// ─────────────────────────────────────────────────────────────
// HANDLER PRINCIPAL DEL BOT
// ─────────────────────────────────────────────────────────────

export async function handler(
  medplum: MedplumClient,
  event: BotEvent<Observation | Patient>,
): Promise<void> {
  console.log('[PREVENT Bot] Iniciando — evento:', event.input?.resourceType);

  // 1. Determinar el Patient a partir del trigger
  let patientId: string;

  if (event.input?.resourceType === 'Observation') {
    const obs = event.input as Observation;
    const ref = obs.subject?.reference;
    if (!ref) {
      console.warn('[PREVENT Bot] Observation sin subject.reference — abortando');
      return;
    }
    patientId = ref.replace('Patient/', '');
  } else if (event.input?.resourceType === 'Patient') {
    patientId = (event.input as Patient).id!;
  } else {
    console.error('[PREVENT Bot] Tipo de recurso no soportado:', event.input?.resourceType);
    return;
  }

  const patientRef = `Patient/${patientId}`;

  // 2. Cargar el paciente
  const patient = await medplum.readResource('Patient', patientId);
  console.log(`[PREVENT Bot] Procesando: ${patient.name?.[0]?.family}, ${patient.name?.[0]?.given?.join(' ')}`);

  // 3. Extraer los predictores desde Observations FHIR
  let input: PreventInput;
  try {
    input = await extractPreventInput(medplum, patient, patientId);
  } catch (err) {
    if (err instanceof PreventValidationError) {
      console.warn(`[PREVENT Bot] Validación fallida: ${err.message}. Se omite el cálculo.`);
      await createMissingDataNote(medplum, patientRef, err.message);
      return;
    }
    if (err instanceof MissingPredictorError) {
      console.warn(`[PREVENT Bot] Predictor faltante: ${err.message}. Se necesitan más datos.`);
      await createMissingDataNote(medplum, patientRef, err.message);
      return;
    }
    throw err;
  }

  // 4. Calcular PREVENT
  console.log('[PREVENT Bot] Ejecutando cálculo PREVENT 2024...');
  const result = calculatePREVENT(input);

  console.log(`[PREVENT Bot] Resultados:
  CVD 10y:   ${(result.cvd10y * 100).toFixed(1)}%
  ASCVD 10y: ${(result.ascvd10y * 100).toFixed(1)}%
  HF 10y:    ${(result.hf10y * 100).toFixed(1)}%
  Categoría: ${result.riskCategory}`);

  // 5. Construir y persistir el RiskAssessment FHIR
  const riskAssessmentData = buildRiskAssessmentFHIR(
    result,
    patientRef,
    'Bot/prevent-uca', // ID del Bot en Medplum
  );

  const saved = await medplum.createResource(riskAssessmentData as RiskAssessment);
  console.log(`[PREVENT Bot] RiskAssessment guardado: ${saved.id}`);

  // 6. Alertas para riesgo alto o muy alto
  if (result.riskCategory === 'high') {
    await createHighRiskAlert(medplum, patient, patientRef, result.cvd10y, result.hf10y);
  }

  // 7. Loggear en Communication para la historia clínica
  await createClinicalNote(medplum, patientRef, result, saved.id!);

  console.log('[PREVENT Bot] Completado exitosamente.');
}

// ─────────────────────────────────────────────────────────────
// EXTRACCIÓN DE PREDICTORES DESDE OBSERVATIONS FHIR
// ─────────────────────────────────────────────────────────────

class MissingPredictorError extends Error {
  constructor(predictor: string) {
    super(`Predictor requerido no encontrado en historial: ${predictor}. Ventana: ${LOOKBACK_DAYS} días.`);
    this.name = 'MissingPredictorError';
  }
}

async function extractPreventInput(
  medplum: MedplumClient,
  patient: Patient,
  patientId: string,
): Promise<PreventInput> {

  const since = new Date();
  since.setDate(since.getDate() - LOOKBACK_DAYS);
  const sinceISO = since.toISOString().split('T')[0];

  // Buscar todas las Observations relevantes del paciente en la ventana
  const bundle = await medplum.search('Observation', {
    subject: `Patient/${patientId}`,
    code: Object.values(LOINC_CODES).join(','),
    date: `ge${sinceISO}`,
    _sort: '-date',
    _count: '100',
  });

  const observations = bundle.entry?.map(e => e.resource as Observation) ?? [];

  // Helper: última Observation de un código LOINC dado
  const getLatest = (loincCode: string): Observation | undefined => {
    return observations.find(obs =>
      obs.code?.coding?.some(c =>
        c.system === 'http://loinc.org' && c.code === loincCode
      )
    );
  };

  // Helper: extraer valor numérico
  const getValue = (obs: Observation | undefined, loincCode: string, name: string): number => {
    if (!obs) throw new MissingPredictorError(`${name} (LOINC ${loincCode})`);
    const val = obs.valueQuantity?.value;
    if (val === undefined) throw new MissingPredictorError(`${name}: sin valor numérico`);
    return val;
  };

  // Extraer valores numéricos
  const sbp   = getValue(getLatest(LOINC_CODES.SBP),               LOINC_CODES.SBP,               'TA sistólica');
  const tc    = getValue(getLatest(LOINC_CODES.TOTAL_CHOLESTEROL),  LOINC_CODES.TOTAL_CHOLESTEROL,  'Colesterol total');
  const hdl   = getValue(getLatest(LOINC_CODES.HDL_C),             LOINC_CODES.HDL_C,              'HDL-C');
  const egfr  = getValue(getLatest(LOINC_CODES.EGFR),              LOINC_CODES.EGFR,               'eGFR');
  const bmi   = getValue(getLatest(LOINC_CODES.BMI),               LOINC_CODES.BMI,                'IMC');

  // Edad desde birthDate del Patient
  const age = computeAge(patient.birthDate);
  if (!age) throw new MissingPredictorError('Fecha de nacimiento del paciente');

  // Sexo biológico desde Patient.gender
  const sex = parseSex(patient.gender);

  // Condiciones: diabetes y tabaquismo desde Condition o extensión
  // En producción, buscar en Condition con SNOMED/ICD-10
  const conditions = await medplum.search('Condition', {
    subject: `Patient/${patientId}`,
    'clinical-status': 'active',
  });
  const conditionCodes = conditions.entry
    ?.flatMap(e => (e.resource as any).code?.coding?.map((c: any) => c.code) ?? []) ?? [];

  const diabetes       = hasDiabetes(conditionCodes);
  const currentSmoker  = hasSmoking(conditionCodes);

  // Medicamentos: antihipertensivos y estatinas desde MedicationRequest activos
  const medReqs = await medplum.search('MedicationRequest', {
    subject: `Patient/${patientId}`,
    status: 'active',
  });
  const medCodes = medReqs.entry
    ?.flatMap(e => (e.resource as any).medicationCodeableConcept?.coding?.map((c: any) => c.code) ?? []) ?? [];

  const onAntihypertensive = hasAntihypertensive(medCodes);
  const onStatin           = hasStatin(medCodes);

  console.log(`[PREVENT Bot] Predictores extraídos:
  Edad: ${age}  Sexo: ${sex}  IMC: ${bmi}
  SBP: ${sbp} mmHg  TC: ${tc} mg/dL  HDL: ${hdl} mg/dL  eGFR: ${egfr}
  DM: ${diabetes}  Tabaco: ${currentSmoker}
  AHTN: ${onAntihypertensive}  Estatina: ${onStatin}`);

  return { sex, age, sbp, totalCholesterol: tc, hdlC: hdl, eGFR: egfr, bmi,
           diabetes, currentSmoker, onAntihypertensive, onStatin };
}

// ─────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────

function computeAge(birthDate?: string): number | null {
  if (!birthDate) return null;
  const born = new Date(birthDate);
  const now  = new Date();
  const age  = now.getFullYear() - born.getFullYear();
  const m    = now.getMonth() - born.getMonth();
  return m < 0 || (m === 0 && now.getDate() < born.getDate()) ? age - 1 : age;
}

function parseSex(gender?: string): BiologicalSex {
  return gender === 'female' ? 'female' : 'male';
}

// Diabetes — SNOMED 73211009 (DM2), 44054006 (DM2 alt), ICD-10 E11*
function hasDiabetes(codes: string[]): boolean {
  const DM_CODES = ['73211009', '44054006', 'E11', 'E11.9', 'E10', 'E10.9'];
  return codes.some(c => DM_CODES.some(dc => c.startsWith(dc)));
}

// Tabaquismo activo — SNOMED 77176002
function hasSmoking(codes: string[]): boolean {
  const SMOKE_CODES = ['77176002', 'F17', 'Z87.891'];
  return codes.some(c => SMOKE_CODES.some(sc => c.startsWith(sc)));
}

// Antihipertensivos — RxNorm o ATC C02/C03/C07/C08/C09
function hasAntihypertensive(codes: string[]): boolean {
  const ATC_PREFIXES = ['C02', 'C03', 'C07', 'C08', 'C09'];
  return codes.some(c => ATC_PREFIXES.some(p => c.toUpperCase().startsWith(p)));
}

// Estatinas — ATC C10AA
function hasStatin(codes: string[]): boolean {
  return codes.some(c => c.toUpperCase().startsWith('C10AA'));
}

// ─────────────────────────────────────────────────────────────
// ALERTA DE RIESGO ALTO
// ─────────────────────────────────────────────────────────────

async function createHighRiskAlert(
  medplum: MedplumClient,
  patient: Patient,
  patientRef: string,
  cvd10y: number,
  hf10y: number,
): Promise<void> {
  const name = `${patient.name?.[0]?.family}, ${patient.name?.[0]?.given?.join(' ')}`;
  const msg  = `⚠️ ALERTA PREVENT — Riesgo cardiovascular ALTO\n` +
               `Paciente: ${name}\n` +
               `CVD 10 años: ${(cvd10y * 100).toFixed(1)}%\n` +
               `IC incidente 10 años: ${(hf10y * 100).toFixed(1)}%\n` +
               `Acción requerida: Revisar GDMT e iniciar o intensificar tratamiento preventivo según guías AHA/ACC 2022.`;

  await medplum.createResource({
    resourceType: 'Communication',
    status: 'completed',
    category: [{
      coding: [{
        system: 'http://terminology.hl7.org/CodeSystem/communication-category',
        code: 'alert',
        display: 'Alert',
      }],
    }],
    priority: 'urgent',
    subject: { reference: patientRef },
    payload: [{ contentString: msg }],
    sent: new Date().toISOString(),
    extension: [{
      url: 'https://api.medplum.com.ar/fhir/StructureDefinition/alert-type',
      valueCode: 'prevent-high-risk',
    }],
  } as Communication);

  console.log('[PREVENT Bot] Alerta de riesgo alto creada.');
}

// ─────────────────────────────────────────────────────────────
// NOTA CLÍNICA EN HISTORIA
// ─────────────────────────────────────────────────────────────

async function createClinicalNote(
  medplum: MedplumClient,
  patientRef: string,
  result: import('./prevent-engine').PreventResult,
  riskAssessmentId: string,
): Promise<void> {
  const p = (v: number) => `${(v * 100).toFixed(1)}%`;
  const note = `CÁLCULO AUTOMÁTICO PREVENT (AHA 2024)\n` +
    `Modelo: ${result.modelVersion} | ${new Date(result.calculatedAt).toLocaleDateString('es-AR')}\n\n` +
    `RIESGO A 10 AÑOS:\n` +
    `  CVD total:  ${p(result.cvd10y)}\n` +
    `  ASCVD:      ${p(result.ascvd10y)}\n` +
    `  IC incidente: ${p(result.hf10y)}\n\n` +
    `RIESGO A 30 AÑOS:\n` +
    `  CVD total:  ${p(result.cvd30y)}\n` +
    `  ASCVD:      ${p(result.ascvd30y)}\n` +
    `  IC:         ${p(result.hf30y)}\n\n` +
    `Categoría AHA/ACC 2019: ${result.riskCategory.toUpperCase()}\n` +
    `RiskAssessment FHIR: ${riskAssessmentId}`;

  await medplum.createResource({
    resourceType: 'Communication',
    status: 'completed',
    category: [{
      coding: [{
        system: 'http://terminology.hl7.org/CodeSystem/communication-category',
        code: 'notification',
      }],
    }],
    subject: { reference: patientRef },
    payload: [{ contentString: note }],
    sent: new Date().toISOString(),
    extension: [{
      url: 'https://api.medplum.com.ar/fhir/StructureDefinition/note-type',
      valueCode: 'prevent-calculation-log',
    }],
  } as Communication);
}

// ─────────────────────────────────────────────────────────────
// NOTA DE DATOS FALTANTES
// ─────────────────────────────────────────────────────────────

async function createMissingDataNote(
  medplum: MedplumClient,
  patientRef: string,
  reason: string,
): Promise<void> {
  await medplum.createResource({
    resourceType: 'Communication',
    status: 'completed',
    category: [{
      coding: [{
        system: 'http://terminology.hl7.org/CodeSystem/communication-category',
        code: 'notification',
      }],
    }],
    subject: { reference: patientRef },
    payload: [{
      contentString: `PREVENT Bot: cálculo incompleto por datos insuficientes.\nMotivo: ${reason}\nCompletar los parámetros faltantes para obtener la estimación de riesgo.`,
    }],
    sent: new Date().toISOString(),
  } as Communication);
}
