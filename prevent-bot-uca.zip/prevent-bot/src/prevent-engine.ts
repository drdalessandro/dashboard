/**
 * PREVENT Engine — AHA Predicting Risk of CVD EVENTs
 * Khan et al., Circulation 2024;149:430–449
 * DOI: 10.1161/CIRCULATIONAHA.123.067626
 *
 * Implementa el modelo base (Table 2) sex-specific, race-free.
 * Predice riesgo a 10 y 30 años de:
 *   - CVD total  (ASCVD + IC)
 *   - ASCVD      (IAM + ACV)
 *   - IC         (Insuficiencia Cardíaca incidente)
 *
 * Uso exclusivo en prevención PRIMARIA (sin CVD conocida).
 * No reemplaza juicio clínico especializado.
 */

// ─────────────────────────────────────────────────────────────
// TIPOS DE ENTRADA / SALIDA
// ─────────────────────────────────────────────────────────────

export type BiologicalSex = 'female' | 'male';

export interface PreventInput {
  sex: BiologicalSex;
  age: number;           // años, 30–79
  sbp: number;           // TA sistólica mmHg, 90–200
  totalCholesterol: number; // mg/dL, 130–320
  hdlC: number;          // HDL-C mg/dL, 20–100
  eGFR: number;          // CKD-EPI 2021, mL/min/1.73m², 15–130
  bmi: number;           // kg/m², 18.5–<40 (solo para HF)
  diabetes: boolean;
  currentSmoker: boolean;
  onAntihypertensive: boolean;
  onStatin: boolean;
}

export interface PreventResult {
  input: PreventInput;
  // Riesgo a 10 años
  cvd10y: number;        // CVD total (ASCVD + IC)
  ascvd10y: number;      // Solo ASCVD
  hf10y: number;         // Solo IC incidente
  // Riesgo a 30 años
  cvd30y: number;
  ascvd30y: number;
  hf30y: number;
  // Riesgo clasificado
  riskCategory: 'low' | 'borderline' | 'intermediate' | 'high';
  // Puntajes lineales (para logging/auditoría)
  lp: { cvd: number; ascvd: number; hf: number };
  // Metadatos
  calculatedAt: string;
  modelVersion: 'PREVENT-2024-base';
}

// ─────────────────────────────────────────────────────────────
// VALIDACIÓN DE ENTRADA
// ─────────────────────────────────────────────────────────────

export class PreventValidationError extends Error {
  constructor(public field: string, public value: number, public allowed: string) {
    super(`PREVENT: campo '${field}' con valor ${value} fuera de rango ${allowed}`);
    this.name = 'PreventValidationError';
  }
}

function validate(input: PreventInput): void {
  const checks: Array<[string, number, number, number]> = [
    ['age',             input.age,             30,  79],
    ['sbp',             input.sbp,             90, 200],
    ['totalCholesterol',input.totalCholesterol,130, 320],
    ['hdlC',            input.hdlC,             20, 100],
    ['eGFR',            input.eGFR,             15, 130],
    ['bmi',             input.bmi,             18.5, 39.9],
  ];
  for (const [field, val, min, max] of checks) {
    if (val < min || val > max) {
      throw new PreventValidationError(field, val, `[${min}–${max}]`);
    }
  }
}

// ─────────────────────────────────────────────────────────────
// CONVERSIONES DE UNIDADES
// ─────────────────────────────────────────────────────────────

const MG_DL_TO_MMOL = 1 / 38.67; // colesterol mg/dL → mmol/L

// ─────────────────────────────────────────────────────────────
// COEFICIENTES — TABLA 2 (Khan et al. 2024)
// Modelo centrado en: edad 55y, non-HDL-C 3.5 mmol/L,
//   HDL-C 1.3 mmol/L, SBP 130 mmHg
// ─────────────────────────────────────────────────────────────

interface ModelCoefs {
  nonHDL:         number;  // non-HDL-C per 1 mmol/L
  nonHDL_age:     number;  // interacción non-HDL × edad
  hdl:            number;  // HDL-C per 0.3 mmol/L
  hdl_age:        number;  // interacción HDL × edad
  sbp_lo:         number;  // SBP <110 per 20 mmHg
  sbp_hi:         number;  // SBP ≥110 per 20 mmHg
  sbp_hi_age:     number;  // interacción SBP≥110 × edad
  dm:             number;  // diabetes (sí/no)
  dm_age:         number;  // interacción DM × edad
  smoke:          number;  // tabaquismo activo
  smoke_age:      number;  // interacción tabaco × edad
  egfr_lo:        number;  // eGFR <60 per –15 mL/min
  egfr_lo_age:    number;  // interacción eGFR<60 × edad
  egfr_hi:        number;  // eGFR ≥60 per –15 mL/min
  ahtn:           number;  // uso de antihipertensivo
  statin:         number;  // uso de estatina
  sbp_treated:    number;  // interacción SBP tratado × SBP≥110
  // Solo para HF:
  bmi_lo?:        number;  // BMI <30 per 5 kg/m²
  bmi_hi?:        number;  // BMI ≥30 per 5 kg/m²
}

// --- CVD Total ---
const CVD_F: ModelCoefs = {
  nonHDL: Math.log(1.03),       nonHDL_age: Math.log(0.92),
  hdl: Math.log(0.85),          hdl_age: Math.log(1.03),
  sbp_lo: Math.log(0.78),       sbp_hi: Math.log(1.43),   sbp_hi_age: Math.log(0.91),
  dm: Math.log(2.39),           dm_age: Math.log(0.77),
  smoke: Math.log(1.74),        smoke_age: Math.log(0.93),
  egfr_lo: Math.log(1.94),      egfr_lo_age: Math.log(0.87),  egfr_hi: Math.log(1.04),
  ahtn: Math.log(1.37),         statin: Math.log(0.86),    sbp_treated: Math.log(0.93),
};
const CVD_M: ModelCoefs = {
  nonHDL: Math.log(1.07),       nonHDL_age: Math.log(0.95),
  hdl: Math.log(0.91),          hdl_age: Math.log(1.02),
  sbp_lo: Math.log(0.63),       sbp_hi: Math.log(1.40),   sbp_hi_age: Math.log(0.90),
  dm: Math.log(2.18),           dm_age: Math.log(0.81),
  smoke: Math.log(1.59),        smoke_age: Math.log(0.92),
  egfr_lo: Math.log(1.86),      egfr_lo_age: Math.log(0.89),  egfr_hi: Math.log(1.01),
  ahtn: Math.log(1.34),         statin: Math.log(0.86),    sbp_treated: Math.log(0.95),
};

// --- ASCVD ---
const ASCVD_F: ModelCoefs = {
  nonHDL: Math.log(1.12),       nonHDL_age: Math.log(0.95),
  hdl: Math.log(0.86),          hdl_age: Math.log(1.04),
  sbp_lo: Math.log(0.91),       sbp_hi: Math.log(1.44),   sbp_hi_age: Math.log(0.91),
  dm: Math.log(2.35),           dm_age: Math.log(0.79),
  smoke: Math.log(1.67),        smoke_age: Math.log(0.93),
  egfr_lo: Math.log(1.75),      egfr_lo_age: Math.log(0.87),  egfr_hi: Math.log(1.04),
  ahtn: Math.log(1.26),         statin: Math.log(0.93),    sbp_treated: Math.log(0.96),
};
const ASCVD_M: ModelCoefs = {
  nonHDL: Math.log(1.17),       nonHDL_age: Math.log(0.97),
  hdl: Math.log(0.89),          hdl_age: Math.log(1.03),
  sbp_lo: Math.log(0.73),       sbp_hi: Math.log(1.39),   sbp_hi_age: Math.log(0.91),
  dm: Math.log(2.10),           dm_age: Math.log(0.83),
  smoke: Math.log(1.53),        smoke_age: Math.log(0.92),
  egfr_lo: Math.log(1.59),      egfr_lo_age: Math.log(0.92),  egfr_hi: Math.log(1.01),
  ahtn: Math.log(1.23),         statin: Math.log(0.90),    sbp_treated: Math.log(0.96),
};

// --- HF (Insuficiencia Cardíaca) — incluye BMI, sin colesterol ---
const HF_F: ModelCoefs = {
  nonHDL: 0, nonHDL_age: 0, hdl: 0, hdl_age: 0, // no aplica a HF
  sbp_lo: Math.log(0.63),       sbp_hi: Math.log(1.44),   sbp_hi_age: Math.log(0.91),
  dm: Math.log(2.86),           dm_age: Math.log(0.71),
  smoke: Math.log(1.84),        smoke_age: Math.log(0.90),
  egfr_lo: Math.log(2.26),      egfr_lo_age: Math.log(0.85),  egfr_hi: Math.log(1.05),
  ahtn: Math.log(1.42),         statin: 0,                 sbp_treated: Math.log(0.90),
  bmi_lo: Math.log(0.98),       bmi_hi: Math.log(1.35),
};
const HF_M: ModelCoefs = {
  nonHDL: 0, nonHDL_age: 0, hdl: 0, hdl_age: 0,
  sbp_lo: Math.log(0.49),       sbp_hi: Math.log(1.45),   sbp_hi_age: Math.log(0.88),
  dm: Math.log(2.56),           dm_age: Math.log(0.75),
  smoke: Math.log(1.70),        smoke_age: Math.log(0.88),
  egfr_lo: Math.log(2.19),      egfr_lo_age: Math.log(0.87),  egfr_hi: Math.log(1.02),
  ahtn: Math.log(1.35),         statin: 0,                 sbp_treated: Math.log(0.95),
  bmi_lo: Math.log(0.93),       bmi_hi: Math.log(1.46),
};

// ─────────────────────────────────────────────────────────────
// HAZARDS DE REFERENCIA (baseline hazards, calibrados
// a la media de las cohortes de validación)
// Aproximaciones basadas en Figuras 2 y 3 del paper.
// ─────────────────────────────────────────────────────────────

const BASELINE = {
  female: {
    cvd10:   0.0268,  ascvd10: 0.0162,  hf10:  0.0138,
    cvd30:   0.1820,  ascvd30: 0.1050,  hf30:  0.1220,
  },
  male: {
    cvd10:   0.0385,  ascvd10: 0.0248,  hf10:  0.0175,
    cvd30:   0.2780,  ascvd30: 0.1820,  hf30:  0.1600,
  },
};

// ─────────────────────────────────────────────────────────────
// PREDICTOR LINEAL (LP)
// ─────────────────────────────────────────────────────────────

function computeLP(coef: ModelCoefs, vars: {
  nonHDL: number; hdl: number;
  sbpLow: number; sbpHigh: number;
  ageDelta: number; dm: number; smoke: number;
  egfrLow: number; egfrHigh: number;
  ahtn: number; statin: number;
  bmiLow?: number; bmiHigh?: number;
}): number {
  const v = vars;
  return (
    coef.nonHDL      * v.nonHDL    + coef.nonHDL_age  * v.nonHDL   * v.ageDelta
  + coef.hdl         * v.hdl       + coef.hdl_age     * v.hdl      * v.ageDelta
  + coef.sbp_lo      * v.sbpLow
  + coef.sbp_hi      * v.sbpHigh   + coef.sbp_hi_age  * v.sbpHigh  * v.ageDelta
  + coef.dm          * v.dm        + coef.dm_age       * v.dm       * v.ageDelta
  + coef.smoke       * v.smoke     + coef.smoke_age    * v.smoke    * v.ageDelta
  + coef.egfr_lo     * v.egfrLow   + coef.egfr_lo_age * v.egfrLow  * v.ageDelta
  + coef.egfr_hi     * v.egfrHigh
  + coef.ahtn        * v.ahtn
  + coef.statin      * v.statin
  + coef.sbp_treated * v.sbpHigh   * v.ahtn
  + (coef.bmi_lo  ?? 0) * (v.bmiLow  ?? 0)
  + (coef.bmi_hi  ?? 0) * (v.bmiHigh ?? 0)
  );
}

// ─────────────────────────────────────────────────────────────
// RIESGO ACUMULADO (modelo de riesgo competitivo simplificado)
// ─────────────────────────────────────────────────────────────

function cumulativeRisk(baselineHazard: number, lp: number): number {
  const risk = 1 - Math.exp(-baselineHazard * Math.exp(lp));
  return Math.max(0, Math.min(0.99, risk));
}

// ─────────────────────────────────────────────────────────────
// CLASIFICACIÓN DE RIESGO (AHA Primary Prevention 2019)
// ─────────────────────────────────────────────────────────────

function categorize(ascvd10y: number): PreventResult['riskCategory'] {
  if (ascvd10y < 0.05)  return 'low';
  if (ascvd10y < 0.075) return 'borderline';
  if (ascvd10y < 0.20)  return 'intermediate';
  return 'high';
}

// ─────────────────────────────────────────────────────────────
// FUNCIÓN PRINCIPAL
// ─────────────────────────────────────────────────────────────

export function calculatePREVENT(input: PreventInput): PreventResult {
  validate(input);

  const f = input.sex === 'female';
  const bh = f ? BASELINE.female : BASELINE.male;

  // Centrados según el paper (edad 55, non-HDL 3.5 mmol/L, HDL 1.3 mmol/L, SBP 130 mmHg)
  const ageDelta   = (input.age - 55) / 10;
  const nonHDL_mmol = ((input.totalCholesterol - input.hdlC) * MG_DL_TO_MMOL) - 3.5;
  const hdl_mmol    = (input.hdlC * MG_DL_TO_MMOL / 0.3) - (1.3 / 0.3);

  const sbpLow  = input.sbp < 110  ? (input.sbp - 110) / 20 : 0;
  const sbpHigh = input.sbp >= 110 ? (input.sbp - 130) / 20 : 0;

  const egfrLow  = input.eGFR < 60  ? (input.eGFR - 60) / -15 : 0;
  const egfrHigh = input.eGFR >= 60 ? (input.eGFR - 90) / -15 : 0;

  const bmiLow  = input.bmi < 30  ? (input.bmi - 25) / 5 : 0;
  const bmiHigh = input.bmi >= 30 ? (input.bmi - 30) / 5 : 0;

  const dm    = input.diabetes           ? 1 : 0;
  const smoke = input.currentSmoker      ? 1 : 0;
  const ahtn  = input.onAntihypertensive ? 1 : 0;
  const stat  = input.onStatin           ? 1 : 0;

  const baseVars = { nonHDL: nonHDL_mmol, hdl: hdl_mmol, sbpLow, sbpHigh,
                     ageDelta, dm, smoke, egfrLow, egfrHigh, ahtn, statin: stat };
  const hfVars   = { ...baseVars, bmiLow, bmiHigh };

  const cvdCoef   = f ? CVD_F   : CVD_M;
  const ascvdCoef = f ? ASCVD_F : ASCVD_M;
  const hfCoef    = f ? HF_F    : HF_M;

  const lpCVD   = computeLP(cvdCoef,   baseVars);
  const lpASCVD = computeLP(ascvdCoef, baseVars);
  const lpHF    = computeLP(hfCoef,    hfVars);

  const cvd10y   = cumulativeRisk(bh.cvd10,   lpCVD);
  const ascvd10y = cumulativeRisk(bh.ascvd10, lpASCVD);
  const hf10y    = cumulativeRisk(bh.hf10,    lpHF);
  const cvd30y   = cumulativeRisk(bh.cvd30,   lpCVD);
  const ascvd30y = cumulativeRisk(bh.ascvd30, lpASCVD);
  const hf30y    = cumulativeRisk(bh.hf30,    lpHF);

  return {
    input,
    cvd10y, ascvd10y, hf10y,
    cvd30y, ascvd30y, hf30y,
    riskCategory: categorize(ascvd10y),
    lp: { cvd: lpCVD, ascvd: lpASCVD, hf: lpHF },
    calculatedAt: new Date().toISOString(),
    modelVersion: 'PREVENT-2024-base',
  };
}
