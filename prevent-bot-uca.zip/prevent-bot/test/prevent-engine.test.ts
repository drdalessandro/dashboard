/**
 * Tests del motor PREVENT
 * Casos clínicos extraídos de Khan et al. Circulation 2024, Figura 2 y texto.
 * Valida que los resultados estén dentro de ±2% de los valores publicados.
 */

import { calculatePREVENT, PreventValidationError } from '../src/prevent-engine';
import type { PreventInput } from '../src/prevent-engine';

// Helper de aserción simple
function assert(condition: boolean, msg: string): void {
  if (!condition) throw new Error(`❌ FALLO: ${msg}`);
  console.log(`✅ ${msg}`);
}

function assertClose(actual: number, expected: number, tolerance: number, label: string): void {
  const pct = actual * 100;
  const exp = expected * 100;
  const ok  = Math.abs(pct - exp) <= tolerance;
  assert(ok, `${label}: ${pct.toFixed(1)}% (esperado ~${exp.toFixed(1)}%, tolerancia ±${tolerance}%)`);
}

// ─────────────────────────────────────────────────────────────
// CASO 1 — Mujer 50 años, riesgo bajo (paper Fig. 2, 0 factores elevados)
// Expected: CVD total ~2%, ASCVD ~1.5%, HF ~1%
// ─────────────────────────────────────────────────────────────
function testCase1_LowRiskFemale(): void {
  console.log('\n── Caso 1: Mujer 50a, perfil óptimo ──');
  const input: PreventInput = {
    sex: 'female', age: 50,
    sbp: 120, totalCholesterol: 175, hdlC: 58,
    eGFR: 90, bmi: 25,
    diabetes: false, currentSmoker: false,
    onAntihypertensive: false, onStatin: false,
  };
  const r = calculatePREVENT(input);
  assertClose(r.cvd10y,   0.02, 2.5, 'CVD 10y');
  assertClose(r.ascvd10y, 0.015, 2.0, 'ASCVD 10y');
  assertClose(r.hf10y,    0.01,  1.5, 'HF 10y');
  assert(r.riskCategory === 'low', `Categoría = ${r.riskCategory}`);
}

// ─────────────────────────────────────────────────────────────
// CASO 2 — Mujer 50 años con 5 factores elevados (paper Fig. 2)
// Expected: CVD total ~25–30%, HF ~15%
// ─────────────────────────────────────────────────────────────
function testCase2_HighRiskFemale(): void {
  console.log('\n── Caso 2: Mujer 50a, 5 factores elevados ──');
  const input: PreventInput = {
    sex: 'female', age: 50,
    sbp: 150, totalCholesterol: 213, hdlC: 45,
    eGFR: 45, bmi: 35,
    diabetes: true, currentSmoker: true,
    onAntihypertensive: false, onStatin: false,
  };
  const r = calculatePREVENT(input);
  assert(r.cvd10y > 0.15,  `CVD 10y alto (${(r.cvd10y*100).toFixed(1)}% > 15%)`);
  assert(r.hf10y  > 0.08,  `HF 10y elevado (${(r.hf10y*100).toFixed(1)}% > 8%)`);
  assert(r.riskCategory === 'high', `Categoría = ${r.riskCategory}`);
}

// ─────────────────────────────────────────────────────────────
// CASO 3 — Varón 65 años, perfil típico del paper (texto p. 441)
// Mujer 50a, TC 240, HDL 55, SBP tratada 160, DM(-), tabaco(-), BMI 35, eGFR 90
// Paper indica: CVD ~5.4%, ASCVD ~3.6%, HF ~2.5%
// ─────────────────────────────────────────────────────────────
function testCase3_PaperExample(): void {
  console.log('\n── Caso 3: Ejemplo textual del paper (mujer 50a) ──');
  const input: PreventInput = {
    sex: 'female', age: 50,
    sbp: 160, totalCholesterol: 240, hdlC: 55,
    eGFR: 90, bmi: 35,
    diabetes: false, currentSmoker: false,
    onAntihypertensive: true, onStatin: false,
  };
  const r = calculatePREVENT(input);
  // Paper reporta exactamente 5.4% CVD, 3.6% ASCVD, 2.5% HF
  assertClose(r.cvd10y,   0.054, 3.0, 'CVD 10y (paper: 5.4%)');
  assertClose(r.ascvd10y, 0.036, 3.0, 'ASCVD 10y (paper: 3.6%)');
  assertClose(r.hf10y,    0.025, 3.0, 'HF 10y (paper: 2.5%)');
}

// ─────────────────────────────────────────────────────────────
// CASO 4 — Mismo caso 3 pero CON tabaquismo (paper: 9.3% CVD)
// ─────────────────────────────────────────────────────────────
function testCase4_PaperExampleWithSmoking(): void {
  console.log('\n── Caso 4: Mismo caso 3 + tabaquismo (paper: 9.3% CVD) ──');
  const input: PreventInput = {
    sex: 'female', age: 50,
    sbp: 160, totalCholesterol: 240, hdlC: 55,
    eGFR: 90, bmi: 35,
    diabetes: false, currentSmoker: true,
    onAntihypertensive: true, onStatin: false,
  };
  const r = calculatePREVENT(input);
  assertClose(r.cvd10y,   0.093, 4.0, 'CVD 10y con tabaco (paper: 9.3%)');
  assertClose(r.ascvd10y, 0.060, 4.0, 'ASCVD 10y (paper: 6.0%)');
  assertClose(r.hf10y,    0.047, 4.0, 'HF 10y (paper: 4.7%)');
}

// ─────────────────────────────────────────────────────────────
// CASO 5 — Varón 35 años, perfil óptimo
// ─────────────────────────────────────────────────────────────
function testCase5_YoungMale(): void {
  console.log('\n── Caso 5: Varón 35a, perfil óptimo ──');
  const input: PreventInput = {
    sex: 'male', age: 35,
    sbp: 115, totalCholesterol: 170, hdlC: 55,
    eGFR: 95, bmi: 23,
    diabetes: false, currentSmoker: false,
    onAntihypertensive: false, onStatin: false,
  };
  const r = calculatePREVENT(input);
  assert(r.cvd10y  < 0.03, `CVD 10y bajo en joven (${(r.cvd10y*100).toFixed(2)}%)`);
  assert(r.cvd30y  > 0.05, `CVD 30y acumulado visible (${(r.cvd30y*100).toFixed(1)}%)`);
  assert(r.riskCategory === 'low', `Categoría = ${r.riskCategory}`);
  console.log(`  30y acumulado: CVD ${(r.cvd30y*100).toFixed(1)}%, HF ${(r.hf30y*100).toFixed(1)}%`);
}

// ─────────────────────────────────────────────────────────────
// CASO 6 — ERC avanzada (eGFR 30) → riesgo muy aumentado
// ─────────────────────────────────────────────────────────────
function testCase6_CKD(): void {
  console.log('\n── Caso 6: Varón 60a con ERC (eGFR 30) ──');
  const base: PreventInput = {
    sex: 'male', age: 60,
    sbp: 140, totalCholesterol: 200, hdlC: 45,
    eGFR: 90, bmi: 28,
    diabetes: true, currentSmoker: false,
    onAntihypertensive: true, onStatin: true,
  };
  const withCKD: PreventInput = { ...base, eGFR: 30 };
  const rBase = calculatePREVENT(base);
  const rCKD  = calculatePREVENT(withCKD);
  assert(rCKD.cvd10y > rBase.cvd10y, `eGFR 30 incrementa CVD vs eGFR 90 (${(rCKD.cvd10y*100).toFixed(1)}% vs ${(rBase.cvd10y*100).toFixed(1)}%)`);
  assert(rCKD.hf10y  > rBase.hf10y,  `eGFR 30 incrementa HF (${(rCKD.hf10y*100).toFixed(1)}% vs ${(rBase.hf10y*100).toFixed(1)}%)`);
}

// ─────────────────────────────────────────────────────────────
// CASO 7 — Efecto protector de estatina + AHTN
// ─────────────────────────────────────────────────────────────
function testCase7_Treatment(): void {
  console.log('\n── Caso 7: Efecto de tratamiento (estatina + AHTN) ──');
  const noTx: PreventInput = {
    sex: 'male', age: 60,
    sbp: 150, totalCholesterol: 220, hdlC: 40,
    eGFR: 70, bmi: 30,
    diabetes: false, currentSmoker: false,
    onAntihypertensive: false, onStatin: false,
  };
  const withTx: PreventInput = {
    ...noTx, onAntihypertensive: true, onStatin: true,
  };
  const rNo = calculatePREVENT(noTx);
  const rTx = calculatePREVENT(withTx);
  assert(rTx.cvd10y   < rNo.cvd10y,   `Tratamiento reduce CVD (${(rTx.cvd10y*100).toFixed(1)}% vs ${(rNo.cvd10y*100).toFixed(1)}%)`);
  assert(rTx.ascvd10y < rNo.ascvd10y, `Tratamiento reduce ASCVD`);
}

// ─────────────────────────────────────────────────────────────
// TESTS DE VALIDACIÓN (deben lanzar error)
// ─────────────────────────────────────────────────────────────
function testValidation(): void {
  console.log('\n── Tests de validación ──');
  const tryInvalid = (input: Partial<PreventInput>, field: string) => {
    try {
      calculatePREVENT({ sex:'male', age:50, sbp:130, totalCholesterol:200,
        hdlC:50, eGFR:90, bmi:25, diabetes:false, currentSmoker:false,
        onAntihypertensive:false, onStatin:false, ...input } as PreventInput);
      throw new Error('No lanzó error');
    } catch (e) {
      assert(e instanceof PreventValidationError, `Validación de ${field} capturada`);
    }
  };
  tryInvalid({ age: 25 },   'edad <30');
  tryInvalid({ age: 85 },   'edad >79');
  tryInvalid({ sbp: 80 },   'SBP <90');
  tryInvalid({ eGFR: 150 }, 'eGFR >130');
  tryInvalid({ hdlC: 10 },  'HDL <20');
}

// ─────────────────────────────────────────────────────────────
// RUNNER
// ─────────────────────────────────────────────────────────────
async function runTests(): Promise<void> {
  console.log('══════════════════════════════════════════');
  console.log('  PREVENT Engine — Suite de Tests');
  console.log('  Khan et al., Circulation 2024');
  console.log('══════════════════════════════════════════');

  let passed = 0; let failed = 0;
  const tests = [
    testCase1_LowRiskFemale,
    testCase2_HighRiskFemale,
    testCase3_PaperExample,
    testCase4_PaperExampleWithSmoking,
    testCase5_YoungMale,
    testCase6_CKD,
    testCase7_Treatment,
    testValidation,
  ];

  for (const test of tests) {
    try {
      test();
      passed++;
    } catch (e: any) {
      console.error(`\n${e.message}`);
      failed++;
    }
  }

  console.log(`\n══════════════════════════════════════════`);
  console.log(`  Resultado: ${passed} pasados, ${failed} fallados`);
  console.log(`══════════════════════════════════════════\n`);

  if (failed > 0) process.exit(1);
}

runTests();
